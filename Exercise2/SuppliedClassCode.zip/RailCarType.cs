﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainSystem
{
    public enum RailCarType
    {
        BOX_CAR,
        COAL_CAR,
        COVERED_HOPPER
    }
}
